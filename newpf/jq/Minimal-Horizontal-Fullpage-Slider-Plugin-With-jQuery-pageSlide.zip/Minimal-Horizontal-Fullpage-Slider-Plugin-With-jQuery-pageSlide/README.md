# pageSlide, jquery全屏翻页插件
jquery plug pageSlide pageFullSlide

#使用方法

1、引用文件

<pre><code>
&lt;link rel="stylesheet" type="text/css" href="pageSlide.css" /&gt;
&lt;script src="jquery-1.9.1.min.js"&gt;&lt;/script&gt;
&lt;script src="pageSlide.js"&gt;&lt;/script&gt;
/code></pre>

2、插件调用
<pre><code>
	&lt;script type="text/javascript"&gt;
		$(function(){
		  $("#pageWrap").pageSlide();
		});
	</script&gt;
/code></pre>
